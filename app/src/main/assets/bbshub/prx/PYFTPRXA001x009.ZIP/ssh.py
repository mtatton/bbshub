#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ADDED ONE SEC DELAY ON CONNECT
# WON'T CONNECT TO PROXY LOCALHOST
# SSH CLOSE ON JOIN
# KEEP ALIVE FLAG SET
# REMOVED COMMAND CAPABILITES -> THE SERVER IS GIVEN BY URL 
# SET DEFAULT HEADERS TO plain, base64
# CLOSED WEBSOCKET ON DISCONNECT
# EXCEPTION ON PUT REMOVED (WSS WAITS FOR SSH CONNECTION)
#
# https://gist.github.com/night-crawler/6213578`
# https://www.reddit.com/r/bbs/comments/9as8hp/tips_on_connecting_to_a_bbs_on_mobile/
#

from tornado.web import RequestHandler, Application
from tornado.websocket import WebSocketHandler
from tornado.ioloop import IOLoop
import tornado.httpserver

import threading
import paramiko
import select
import socket
import Queue
import time
import re


class sshHandler(threading.Thread):

  def __init__(self, host, port, username, password, read_callback, disconnect_callback=None):

    threading.Thread.__init__(self)

    self.ssh = None
    self.chan = None
    self.host = host
    self.port = port
    self.user = username
    self.pwd = password
    self.bufsize = 512
    self.socket = None
    self.alive = threading.Event()
    self.disconnect_callback = disconnect_callback
    self.read_callback = read_callback
    self.write_queue = Queue.Queue()

  def join(self, timeout=None):
    self.ssh.close()
    self.socket.close()
    self.alive.clear()
    threading.Thread.join(self, timeout)

  def connect(self, host=None, port=None):
    try:
      paramiko.util.log_to_file("connection.log", level = "WARN")
      self.ssh = paramiko.SSHClient()
      self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      self.ssh.connect(host or self.host,port or self.port,username=self.user,password=self.pwd,look_for_keys=False) # HERE FILL THE USERNAME AND PASSWORD
      transport = self.ssh.get_transport()
      transport.set_keepalive(60)
      #transport.set_header("Sec-WebSocket-Protocol", "base64") 
      self.chan = self.ssh.invoke_shell()
    except Exception as e:
      print(e)
    print("*** Connected to %s@%s:%s " % (self.user, self.host, self.port))
    self.alive.set()

  def put(self, data):
    if self.alive.isSet():
      self.chan.send(data)
    #else:
    #  raise Exception('--- Exception: Channel send data (put) [ not ready yet ]')

  def run(self):
    self.connect()
    while self.alive.isSet():

      sread, swrite, sexc = select.select([], [self.chan], [], 0.01)
      for self.chan in swrite:
        while True:
          cmd_list = []
          try:
            cmd_list.append(self.chan.recv(256))
          except Queue.Empty:
            break
          if cmd_list:
            self.chan(x)

      sread, swrite, sexc = select.select([self.chan], [], [], 0.01)
      for self.chan in sread:
        try:
          data = self.chan.recv(self.bufsize)
          if not data:
            raise Exception('NO DATA')
          self.read_callback(data)
        except Exception as e:
          if self.disconnect_callback:
            self.disconnect_callback(e)
            print("*** Disconnected from %s@%s:%s " % (self.user, self.host, self.port))


ON_CONNECT = """*** Thank You for using this proxy server.\r """
TELNET_GA = chr(249)
TELNET_IAC = chr(255)

class MessagesHandler(WebSocketHandler):

  sock = None
  hostname = None
  port = None
  
  def check_origin(self, origin):
    return(True)

  #def set_default_headers(self, *args, **kwargs):
    #self.set_header("Sec-WebSocket-Protocol", "binary, base64, plain")
    #self.set_header("Sec-WebSocket-Protocol", 'binary, base64, plain')

  def open(self,p_username, p_password, p_hostname,p_port):

   self.hostname = p_hostname
   self.port=p_port
   self.username=p_username
   self.password=p_password

   self.write_message('''SSH Connection init int progress...\n\r''')
   self.encoding = 'latin-1'
   self.sock = None

   connstr='*** Connecting to ' + self.username + '@' + self.hostname + ' ' + self.port
   self.write_message(connstr + '\n\r')
   #print(connstr)

   time.sleep(1)

   self.replace_ga = True

   x=re.search(r'127.0.0.1|localhost',self.hostname)
   if (x):
     denystr="Wouldn't connect to this host\n\r"
     self.write_message(denystr)
     print(denystr)
   else:          
     self.sock = sshHandler(self.hostname, int(self.port), 'new', 'new', self.process_server_response, self.server_disconnect_handler) # ZNC
     self.sock.start()

 #def _accept_connection(self, handler: WebSocketHandler) -> None:
 #  subprotocol_header = handler.request.headers.get("Sec-WebSocket-Protocol")
 #  if subprotocol_header:
 #    subprotocols = [s.strip() for s in subprotocol_header.split(",")]
 #  else:
 #    subprotocols = []
 #  self.selected_subprotocol = handler.select_subprotocol(subprotocols)
 #  if self.selected_subprotocol:
 #    assert self.selected_subprotocol in subprotocols
 #    handler.set_header("Sec-WebSocket-Protocol", self.selected_subprotocol)

  def process_server_response(self, data):

    if self.replace_ga:
      i = 0

      while True:
        i = data.find(TELNET_IAC + TELNET_GA, i)
        if i == -1:
          break

        if i-1 >= 0:
          if data[i-1] != TELNET_IAC:
            data = data[:i] + "\n" + data[i+2:]
            continue
          i += 2

      data = data.replace(TELNET_IAC*2, TELNET_IAC)

      self.write_message(data.decode(self.encoding, 'replace'))

  def close_server_socket(self):
    if self.sock is None:
      return
    else:
      self.sock.alive.clear()
      self.sock.ssh.close()
      self.close()
      self.sock = None

  def server_disconnect_handler(self, msg):
    try:
      self.close_server_socket() # cannot join
      #print("Server disconnect handler")
    except Exception as e:
      print ("--- Error during socket close %s" % e)
    #self.write_message('*** Disconnected from server: %s\r' % msg)

  def on_message(self, message):
    if self.sock.alive.isSet():
      try:
        encoded_message = message.encode(self.encoding)
        encoded_message = encoded_message.replace(TELNET_IAC, TELNET_IAC*2)
        self.sock.put(encoded_message)
      except Exception as e:
        print "--- Put Exception: " + e

  def on_close(self):
    self.close_server_socket()
    #print "*** WebSocket closed"

application = Application([
    (r'/ssh/(.*)/(.*)/(.*)/(\d+)', MessagesHandler)
])

if __name__ == "__main__":
  #https_server = tornado.httpserver.HTTPServer(application, ssl_options={
  #    "certfile": "cert.pem",
  #   "keyfile": "key.pem",
  #})
  #https_server.listen(8080, '0.0.0.0')
  application.listen(8080, '127.0.0.1')
  IOLoop.instance().start()

