#!/bin/bash
#sudo python ./ssh.py
sudo python ./telnet.py
