#!/bin/bash
python ./ssh.py
#sudo python ./telnet.py
